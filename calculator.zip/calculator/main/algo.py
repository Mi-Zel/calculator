from math import ceil, floor

def numberOffices(employees, working_days, available_days):
    '''employees, working_days, available_days'''
    try:
        return ceil(employees/(available_days/working_days))
    except:
        return 0

def workingDays(employees, available_offices, available_days):
    '''employees, available_offices, available_days'''
    working_days = floor(available_offices*available_days/employees)
    return working_days if working_days <= available_days else available_days

def potentialEmployees(available_offices, available_days, working_days):
    '''available_offices, available_days, working_days'''
    return floor(available_days*available_offices/working_days)

