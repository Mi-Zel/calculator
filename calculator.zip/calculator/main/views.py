from django.shortcuts import render, redirect
from .forms import Offices, OfficesAdvanced, WorkingDays, UnusedOffices, Employees
from .algo import numberOffices, workingDays, potentialEmployees
# Create your views here.

def home(response):
    return render(response, 'main/home.html', {})


def officeCalculator(response):
    if response.method == 'POST':
        form = Offices(response.POST)
        if form.is_valid():
            employees = form.cleaned_data['employees']
            working = form.cleaned_data['working_days']
            available = form.cleaned_data['available_days']
            price_one = form.cleaned_data['price']
            if working <= available:
                offices = numberOffices(employees, working, available)
                price = price_one*offices if price_one else None
                return render(response, 'main/officecalculator.html', {'form':form, 'offices':offices, 'price':price})
            else:
                error = True
                return render(response, 'main/officecalculator.html', {'form':form, 'error':error})
    else:
        form = Offices()
    return render(response, 'main/officecalculator.html', {'form':form})


def advancedOfficeCalculator(response):
    if response.method == 'POST':
        form = OfficesAdvanced(response.POST)
        if form.is_valid():
            employees1 = form.cleaned_data['employees_1']
            employees2 = form.cleaned_data['employees_2']
            employees3 = form.cleaned_data['employees_3']
            working1 = form.cleaned_data['working_days_1']
            working2 = form.cleaned_data['working_days_2'] if form.cleaned_data['working_days_2'] else 0
            working3 = form.cleaned_data['working_days_3'] if form.cleaned_data['working_days_3'] else 0
            available = form.cleaned_data['available_days']
            price_one = form.cleaned_data['price']
            if working1 <= available and working2 <= available and working3 <= available:
                offices1 = numberOffices(employees1, working1, available)
                offices2 = numberOffices(employees2, working2, available)
                offices3 = numberOffices(employees3, working3, available)
                offices = offices1 + offices2 + offices3
                price = price_one*offices if price_one else None 
                return render(response , 'main/advancedofficecalculator.html', {'form':form, 'offices':offices, 'price':price})
            else:
                error = True
                return render(response , 'main/advancedofficecalculator.html', {'form':form, 'error':error})
    else:
        form = OfficesAdvanced()
    return render(response , 'main/advancedofficecalculator.html', {'form':form})


def workingDaysCalculator(response):
    if response.method == 'POST':
        form = WorkingDays(response.POST)
        if form.is_valid():
            employees = form.cleaned_data['employees']
            offices = form.cleaned_data['available_offices']
            available = form.cleaned_data['available_days']
            working = workingDays(employees, offices, available)
            unused = offices-numberOffices(employees, working, available)
            return render(response , 'main/workingdayscalculator.html', {'form':form, 'working':working, 'unused':unused})
    else:
        form = WorkingDays()
    return render(response, 'main/workingdayscalculator.html', {'form':form})


def unusedOfficesCalculator(response):
    if response.method == 'POST':
        form = UnusedOffices(response.POST)
        if form.is_valid():
            employees = form.cleaned_data['employees']
            working = form.cleaned_data['working_days']
            available = form.cleaned_data['available_days']
            offices = form.cleaned_data['available_offices']
            if working <= available:
                unusedoffices = offices-numberOffices(employees, working, available)
                potential_employees = potentialEmployees(unusedoffices, available, working) if unusedoffices>0 else 0
                return render(response , 'main/unusedofficescalculator.html', {'form':form, 'unusedoffices':unusedoffices, 'potential_employees':potential_employees})
            else:
                error = True
                return render(response , 'main/unusedofficescalculator.html', {'form':form, 'error':error})
    else:
        form = UnusedOffices()
    return render(response , 'main/unusedofficescalculator.html', {'form':form})


def employeesCalculator(response):
    if response.method == 'POST':
        form = Employees(response.POST)
        if form.is_valid():
            working = form.cleaned_data['working_days']
            available = form.cleaned_data['available_days']
            offices = form.cleaned_data['available_offices']
            if working <= available:
                potential_employees = potentialEmployees(offices, available, working)
                return render(response , 'main/employeescalculator.html', {'form':form, 'potential_employees':potential_employees})
            else:
                error = True
                return render(response , 'main/employeescalculator.html', {'form':form, 'error':error})
    else:
        form = Employees()
    return render(response , 'main/employeescalculator.html', {'form':form})


