from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('officecalculator/', views.officeCalculator, name='officecalculator'),
    path('advancedofficecalculator/', views.advancedOfficeCalculator, name='advancedofficecalculator'),
    path('workingdayscalculator/', views.workingDaysCalculator, name='workingdayscalculator'),
    path('unusedofficescalculator/', views.unusedOfficesCalculator, name='unusedofficescalculator'),
    path('employeescalculator/', views.employeesCalculator, name='employeescalculator'),
]