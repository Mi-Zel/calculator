from django import forms

class Offices (forms.Form):
    available_days = forms.IntegerField(initial=5, help_text = 'Enter the number of days you have available.', max_value=7, min_value=1)
    working_days = forms.IntegerField(initial=5, help_text = 'Enter the number of days you want your employees to physically come to office.', max_value=7, min_value=1)
    employees = forms.IntegerField(initial=100, help_text = 'Enter the number of your employees.', min_value=1)
    price = forms.DecimalField(label='Price (€)', required=False, help_text='How much do you pay for one office per month?', min_value=0, decimal_places=2)

class OfficesAdvanced (forms.Form):
    available_days = forms.IntegerField(initial=5, help_text = 'Enter the number of days you have available.', max_value=7, min_value=1)
    employees_1 = forms.IntegerField(initial=100, help_text = 'Enter the number of your employees.', min_value=1)
    working_days_1 = forms.IntegerField(initial=5, help_text = 'Enter the number of days you want your employees to physically come to office.', max_value=7, min_value=1)
    employees_2 = forms.IntegerField(required=False, help_text = 'Enter the number of your employees.', min_value=1)
    working_days_2 = forms.IntegerField(required=False, help_text = 'Enter the number of days you want your employees to physically come to office.', max_value=7, min_value=1)
    employees_3 = forms.IntegerField(required=False, help_text = 'Enter the number of your employees.', min_value=1)
    working_days_3 = forms.IntegerField(required=False, help_text = 'Enter the number of days you want your employees to physically come to office.', max_value=7, min_value=1)
    price = forms.DecimalField(label='Price (€)', required=False, help_text='How much do you pay for one office per month?', min_value=0, decimal_places=2)

class WorkingDays (forms.Form):
    available_days = forms.IntegerField(initial=5, help_text = 'Enter the number of days you have available.', max_value=7, min_value=1)
    employees = forms.IntegerField(initial=100, help_text = 'Enter the number of your employees.', min_value=1)
    available_offices = forms.IntegerField(initial=100, help_text='Enter the number of offices you have available.', min_value=1)

class UnusedOffices (forms.Form):
    available_days = forms.IntegerField(initial=5, help_text = 'Enter the number of days you have available.', max_value=7, min_value=1)
    working_days = forms.IntegerField(initial=5, help_text = 'Enter the number of days you want your employees to physically come to office.', max_value=7, min_value=1)
    employees = forms.IntegerField(initial=100, help_text = 'Enter the number of your employees.', min_value=1)
    available_offices = forms.IntegerField(initial=100, help_text='Enter the number of offices you have available.', min_value=1)

class Employees (forms.Form):
    available_days = forms.IntegerField(initial=5, help_text = 'Enter the number of days your employees could possibly go to work.', max_value=7, min_value=1)
    working_days = forms.IntegerField(initial=5, help_text = 'Enter the number of days you want your employees to physically come to office.', max_value=7, min_value=1)
    available_offices = forms.IntegerField(initial=100, help_text='Enter the number of offices you have available.', min_value=1)



